package com.yourorg.user_info;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserInfoServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(UserInfoServerApplication.class, args);
    }
}