package com.yourorg.leaderboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LeaderboardServerApplication {
    public static void main(String[] args) {
        SpringApplication.run(LeaderboardServerApplication.class, args);
    }
}
